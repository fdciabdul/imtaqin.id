![PHP Backdoor](https://github.com/g3ck/PHP-Backdoor/raw/master/assets/img/header.png "PHP Backdoor")
![PHP Backdoor](https://github.com/g3ck/PHP-Backdoor/raw/master/assets/img/screenshot.png "PHP Backdoor")

# PHP Backdoor

## Table of contents

  * [Introduction](#introduction)
  * [Single file built ](#single-file-built)
  * [Files](#files)
  * [Installation](#installation)
  * [Authors](#authors)
  * [&#9760; Use with caution](#-use-with-caution)
  * [Screenshot](#screenshot)
  * [Changelog](#changelog)
  * [License](#license)

## Introduction

PHP terminal is a web-based application that allows to execute terminal commands on a server directly from a browser.

## Single file built

The application is built in single php file. The size of the `dist` file is less than `~5 KB`

## Files

- `dits/terminal.php` - Minimized distribution file
- `src/terminal.php` - Source file

## Installation

- [`Download`](https://github.com/g3ck/PHP-Backdoor/archive/master.zip) **dits/terminal.php** file
- `Upload` **terminal.php** file to your server
- `Run` script by url **[your domain]/terminal.php**
- `Join it`

## Additional commands

- `cls` clear console screen
- `reset` reset console

## Authors

- `Jarek Szulc` <jarek@g3ck.com>
- `G3ck Dev Team` <dev@g3ck.com>

##  &#9760; Use with caution

This script represents a security risk for the server. Do not upload it on a server until you know what you are doing!

## Changelog

[View changelog](https://github.com/g3ck/PHP-Backdoor/blob/master/CHANGELOG.md)

## License

Licensed under the `MIT License`

[View license](https://github.com/g3ck/PHP-Backdoor/blob/master/LICENSE)
