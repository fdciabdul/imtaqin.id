# Change Log

## 2.0 - Released on Maj 26, 2019
  * Changed distribution of the project from "PHP Shell Termianl" to "PHP Backdoor"

## 1.2 - Released on Maj 20, 2019
  * `[new]` Support for `shell_exec` function

## 1.1 - Released on Maj 18, 2019
  * `[new]` JavaScript source code comments

## 1.0 - Released on Maj 17, 2019
  * `[new]` Support for additional functions `system`, `passthru`, `exec`
  * `[change]` Expanding the contents of the `README.md` file.
  * `[new]` PHP source code comments

## [1.0alpha] - Released on Maj 14, 2019
  * Initial release of PHP Backdoor 1
